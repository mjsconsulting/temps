export default {
  details: {
    lastName: "",
    email: "",
    phone: "",
  },
};
