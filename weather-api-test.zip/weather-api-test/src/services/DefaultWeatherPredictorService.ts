import { Weather, WeatherPredictorService } from "./WeatherPredictorService";

export const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export const MockResponse: { [index: string]: Weather } = {
  January: Weather.SNOW,
  February: Weather.SNOW,
  March: Weather.RAINY,
  April: Weather.RAINY,
  May: Weather.CLOUDY,
  June: Weather.SUNNY,
  July: Weather.SUNNY,
  August: Weather.CLOUDY,
  September: Weather.CLOUDY,
  October: Weather.CLOUDY,
  November: Weather.HAIL,
  December: Weather.SNOW,
};

const getMonthName = (date: Date) => monthNames[date.getMonth()];

class DefaultWeatherPredictorService implements WeatherPredictorService {
  public getWeather(date: Date): Weather {
    const weather = MockResponse[getMonthName(date)];
    return weather;
  }
  public updateWeather(date: Date, weather: Weather): void {
    const monthName = getMonthName(date);
    MockResponse[monthName] = weather;
    console.log(" MockResponse[monthName]", MockResponse[monthName]);
  }
}

export default DefaultWeatherPredictorService;
