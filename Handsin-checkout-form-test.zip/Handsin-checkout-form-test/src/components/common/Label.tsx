import React from "react";

type Props = {
  htmlFor: string;
  label: string;
  required: boolean;
};

export default function Label({ htmlFor, label, required }: Props) {
  return (
    <label style={{ display: "block" }} htmlFor={htmlFor}>
      {label} {required && <span style={{ color: "red" }}> *</span>}
    </label>
  );
}
