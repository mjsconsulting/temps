import Details, { IDetails } from "../../components/details/Details";
import * as types from "./actionTypes";

export function createDetailsSuccess(details: IDetails) {
  return { type: types.CREATE_DETAILS, details };
}

export function createDetails(details: IDetails) {
  return function (dispatch: any, getState: any) {
    console.log("createDetails Action details ", details);
    return dispatch(createDetailsSuccess(details));
    // Call the API
    // Handle try catch
    // Assuming everything is fine
    // return new Promise((resolve, reject) => {
    //   dispatch(createDetailsSuccess(details));
    //   //resolve(dispatch(createDetailsSuccess(details)));
    // });
    // catch the error
    // dispatch error action
  };
}
