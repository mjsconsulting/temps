[
  {
    January: "SNOW",
    February: "SNOW",
    March: "RAINY",
    April: "RAINY",
    May: "CLOUDY",
    June: "SUNNY",
    July: "SUNNY",
    August: "CLOUDY",
    September: "CLOUDY",
    October: "CLOUDY",
    November: "HAIL",
    December: "SNOW",
  },
];
