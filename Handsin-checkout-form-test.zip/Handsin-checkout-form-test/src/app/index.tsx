import React from "react";
import Main from "../components/Main";

import "../css/normalize.css";
import "../css/skeleton.css";
import "../css/custom.css";
import "../css/prog-tracker.css";

const App = () => {
  return (
    <div className="container margin-top-3">
      <Main />
    </div>
  );
};

export default App;
