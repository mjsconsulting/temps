import React from "react";
import MultiStep from "./multistep/MultiStep";

import Details from "./details/Details";
import Shipping from "./shipping/Shipping";
import Payment from "./payment/Payment";

const steps = [
  { name: "Details", component: <Details /> },
  { name: "Shipping", component: <Shipping /> },
  { name: "Payment", component: <Payment /> },
];

// custom styles
const prevStyle = { background: "#33c3f0" };
const nextStyle = { background: "#33c3f0" };

const Main = () => {
  return (
    <div className="">
      <MultiStep
        activeStep={0}
        showNavigation={true}
        steps={steps}
        prevStyle={prevStyle}
        nextStyle={nextStyle}
      />
    </div>
  );
};

export default Main;
