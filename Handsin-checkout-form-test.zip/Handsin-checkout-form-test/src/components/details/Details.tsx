import { useState } from "react";
import { connect, useDispatch } from "react-redux";
import { createDetails } from "../../redux/actions";
import TextInput from "../common/TextInput";

export interface IDetails {
  lastName: string;
  email: string;
  phone: string;
}

type Props = {
  createDetails: (details: IDetails) => Promise<any>;
};

export function Details({ createDetails }: Props) {
  const [details, setDetails] = useState({
    lastName: "",
    email: "",
    phone: "",
  });
  const [errors, setErrors] = useState({ lastName: "", email: "", phone: "" });
  const [saving, setSaving] = useState(false);

  const dispatch = useDispatch();

  const onChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newDetails: any = { ...details };
    newDetails[event.target.name] = event.target.value;
    setDetails((prevDetails) => ({ ...prevDetails, ...newDetails }));
  };

  const formIsValid = () => {
    const { lastName, email, phone } = details;
    const errors: any = {};

    if (!lastName) errors.lastName = "Last Name is required.";
    if (!email) errors.email = "Email is required";
    if (!phone) errors.phone = "Phone is required";

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  function handleSave(event: React.MouseEvent<HTMLElement>) {
    event.preventDefault();
    if (!formIsValid()) return;
    setSaving(true);
    dispatch(
      createDetails(details)
      // .then(() => {
      //   // toast.success("Show message for the user that we are good");
      //   // history.push("/shipping");
      // })
      // .catch((error) => { // Assume that the api give us an error
      //   // setSaving(false);
      //   // setErrors({ onSave: error.message });
      // })
    );
  }

  const { lastName, email, phone } = details;

  return (
    <div className="">
      <h3>Details Form</h3>
      <form>
        <div className="row">
          <div className="six columns">
            <TextInput
              label="Last name"
              htmlId="details-form-lastName"
              type="text"
              name="lastName"
              placeholder="appleseed"
              className="u-full-width required"
              value={lastName}
              onChange={onChange}
              error={errors.lastName}
              required
            />
          </div>
        </div>

        <div className="row">
          <div className="six columns">
            <TextInput
              label="Email"
              htmlId="details-form-email"
              type="text"
              name="email"
              placeholder="johnappleseed@gmail.com"
              className="u-full-width required"
              value={email}
              onChange={onChange}
              error={errors.email}
              required
            />
          </div>
        </div>

        <div className="row">
          <div className="six columns">
            <TextInput
              label="Phone Number"
              htmlId="details-form-phone"
              type="text"
              name="phone"
              placeholder="0123456789"
              className="u-full-width required"
              value={phone}
              onChange={onChange}
              error={errors.phone}
              required
            />
          </div>
        </div>

        <button type="submit" disabled={saving} onClick={handleSave}>
          {saving ? "Saving..." : "Go to Shipping"}
        </button>
      </form>
    </div>
  );
}

function mapStateToProps(state: any, ownProps: any) {
  const details = state.details;
  return { details };
}

const mapDispatchToProps = {
  createDetails,
};

export default connect(mapStateToProps, mapDispatchToProps)(Details);
