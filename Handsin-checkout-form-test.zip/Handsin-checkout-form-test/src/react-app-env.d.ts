/// <reference types="react-scripts" />

declare module "react/jsx-runtime" {
  export default any;
}

declare module "react-multistep" {
  export default any;
}
