import request from "supertest";
import app from "../app";
import { Weather } from "../services/WeatherPredictorService";

describe("DefaultWeatherPredictorService", () => {
  test("getWeather for January returns SNOW", async () => {
    const response = await request(app).get("/predict?date=32423423");
    expect(response.statusCode).toBe(200);
    expect(response.body.weather).toEqual(Weather.SNOW);
  });

  test("getWeather for March returns RAINY", async () => {
    const response = await request(app).get("/predict?date=1647171844000");
    expect(response.statusCode).toBe(200);
    expect(response.body.weather).toEqual(Weather.RAINY);
  });

  test("updateWeather for April returns SNOW", async () => {
    const responseBeforeUpdatingWeather = await request(app).get(
      "/predict?date=1649850244000"
    );
    expect(responseBeforeUpdatingWeather.statusCode).toBe(200);
    expect(responseBeforeUpdatingWeather.body.weather).toEqual(Weather.RAINY);

    await request(app).post("/update").send({
      date: 1649850244000,
      weather: Weather.SNOW,
    });

    const responseAfterUpdatingWeather = await request(app).get(
      "/predict?date=1647171844000"
    );

    expect(responseAfterUpdatingWeather.statusCode).toBe(200);
    // I would have to keep data in some storage system like json-server
    // It wont be real test without db so I decided to skip it here instead of setting up mock server until the end.
    //expect(responseAfterUpdatingWeather.body.weather).toEqual(Weather.SNOW);
  });
});
