export default function Payment() {
  return (
    <div className="form-wrapper">
      <h3>Payment Form</h3>
      <form>
        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">Name on card</label>
            <input
              type="text"
              name="example-input"
              placeholder="MR J APPLESEED"
              className="u-full-width required"
            />
          </div>
        </div>

        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">Card number</label>
            <input
              type="text"
              name="example-input"
              placeholder="8888 8888 8888 8888"
              className="u-full-width required"
            />
          </div>
        </div>

        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">CVV</label>
            <input
              type="text"
              name="example-input"
              placeholder="000"
              className="u-full-width required"
            />
          </div>
        </div>

        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">Expiration date</label>
            <input
              type="text"
              name="example-input"
              placeholder="04/22"
              className="u-full-width required"
            />
          </div>
        </div>

        <button>Go back</button>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
