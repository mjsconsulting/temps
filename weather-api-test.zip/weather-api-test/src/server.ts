import app from "./app";

app.listen(3000, () => "Listening on port 8080");
