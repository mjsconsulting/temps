import React from "react";

// Usually we would have a navigation but it is not necessary to invent dummy stuff here
const Header = () => {
  return (
    <>
      {/* <h1>Checkout Form</h1>
      <div className="stepper-wrapper">
        <p>Details</p>
      <p>Shipping</p>
      <p>Payment</p> */}
      {/* </div> */}
    </>
  );
};

export default Header;
