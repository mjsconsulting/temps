import React from "react";
import styled from "styled-components";
import Label from "./Label";

interface Option {
  value: string;
  text: string;
}

type Props = {
  htmlId: string;
  name: string;
  label: string;
  onChange: () => void;
  defaultOption: string;
  value: string;
  error: string;
  options: Option[];
  required?: boolean;
};

export default function SelectInput({
  htmlId,
  name,
  label,
  onChange,
  defaultOption,
  value,
  error,
  options,
  required = false,
}: Props) {
  const Error = styled.div`
    color: red;
  `;

  const Fieldset = styled.div`
    margin-bottom: 16px;
  `;

  const Select = styled.select`
    border: ${error && "solid 1px red"};
    display: block;
  `;

  return (
    <Fieldset>
      <Label htmlFor={htmlId} label={label} required={required} />
      <div className="field">
        <Select
          name={name}
          value={value}
          onChange={onChange}
          className="form-control"
        >
          <option value="">{defaultOption}</option>
          {options.map((option) => {
            return (
              <option key={option.value} value={option.value}>
                {option.text}
              </option>
            );
          })}
        </Select>
        {error && <Error>{error}</Error>}
      </div>
    </Fieldset>
  );
}
