import express from "express";
import jsonServer from "json-server";
import path from "path";

import bodyParser from "body-parser";
import DefaultWeatherPredictorService from "./services/DefaultWeatherPredictorService";
import { Weather } from "./services/WeatherPredictorService";

const router = jsonServer.router(path.join(__dirname, "db.json"));
const middlewares = jsonServer.defaults();

const app = jsonServer.create();
app.use(middlewares);
app.use(jsonServer.bodyParser);

const weatherService = new DefaultWeatherPredictorService();

app.get("/predict", (req: any, res) => {
  const date = new Date(Number(req.query.date));
  const response = weatherService.getWeather(date);
  res.send({ weather: response });
});

app.post("/update", (req, res) => {
  const date = new Date(Number(req.body.date));
  const weather = Weather[req.body.weather as Weather];
  weatherService.updateWeather(date, weather);
  res.send("Well done!");
});

// Easier to write tests when we export app
// app.listen(3000, () => {
//     console.log('The application is listening on port 3000!');
// })

// Use default router
app.use(router);

export default app;
