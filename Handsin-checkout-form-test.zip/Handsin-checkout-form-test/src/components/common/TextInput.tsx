import React from "react";
import styled from "styled-components";
import Label from "./Label";

type Props = {
  htmlId: string;
  name: string;
  label: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  value: string;
  error: string;
  type?: "text" | "number" | "password";
  required?: boolean;
  placeholder?: string;
  children?: React.ReactNode;
  className?: string;
};

const Error = styled.div`
  color: red;
`;

const Fieldset = styled.div`
  margin-bottom: 16px;
`;

const Input = styled.input`
  display: block;
`;

export default function TextInput({
  htmlId,
  name,
  label,
  type = "text",
  required = false,
  onChange,
  placeholder,
  value,
  error,
  children,
  className = "",
  ...props
}: Props) {
  return (
    <Fieldset>
      <Label htmlFor={htmlId} label={label} required={required} />
      <Input
        id={htmlId}
        type={type}
        name={name}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className={className}
        {...props}
      />
      {children}
      {error && <Error>{error}</Error>}
    </Fieldset>
  );
}
