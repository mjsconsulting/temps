import { combineReducers } from "redux";
import details from "./detailsReducer";

const rootReducer = combineReducers({
  details,
});

export default rootReducer;
