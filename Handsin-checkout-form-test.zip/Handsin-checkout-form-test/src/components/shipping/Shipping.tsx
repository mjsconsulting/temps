export default function Shipping() {
  return (
    <div className="form-wrapper">
      <h3>Shipping Form</h3>
      <form>
        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">Address</label>
            <input
              type="text"
              name="example-input"
              placeholder="1 brick lane"
              className="u-full-width required"
            />
          </div>
        </div>
        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">City</label>
            <input
              type="text"
              name="example-input"
              placeholder="London"
              className="u-full-width required"
            />
          </div>
        </div>
        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">Zip code</label>
            <input
              type="text"
              name="example-input"
              placeholder="CE1 4SA"
              className="u-full-width required"
            />
          </div>
        </div>
        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">State/Province</label>
            <input
              type="text"
              name="example-input"
              placeholder="England"
              className="u-full-width required"
            />
          </div>
        </div>
        <div className="row">
          <div className="six columns">
            <label htmlFor="example-input">Country</label>
            <input
              type="text"
              name="example-input"
              placeholder="United Kingdom"
              className="u-full-width required"
            />
          </div>
        </div>

        <button>Go back</button>
        <button>Go to Payment</button>
      </form>
    </div>
  );
}
