import { IDetails } from "../../components/details/Details";
import * as types from "../actions/actionTypes";
import initialState from "./initialState";

export interface Action<T, P> {
  readonly type: T;
  readonly details?: P;
}

export default function detailsReducer(
  state = initialState.details,
  action: Action<string, IDetails>
) {
  switch (action.type) {
    case types.CREATE_DETAILS:
      return { ...state, ...action.details };
    default:
      return state;
  }
}
